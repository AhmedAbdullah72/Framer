import type { ReactNode } from "react"

export const metadata = { title: "reliable-spinach-027970.framer.app" }

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
