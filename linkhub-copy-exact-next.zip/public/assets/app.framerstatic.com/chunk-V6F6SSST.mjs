import{a as o}from"https://app.framerstatic.com/chunk-NHI45D3X.mjs";import{a as r}from"https://app.framerstatic.com/chunk-SWYZG2NI.mjs";import{e as t}from"https://app.framerstatic.com/chunk-WLHSDIGQ.mjs";var e=t(r(),1);function a(){return(0,e.useContext)(o)}export{a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-V6F6SSST.mjs.map
